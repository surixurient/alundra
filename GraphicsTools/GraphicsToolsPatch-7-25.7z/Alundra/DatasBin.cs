﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Drawing;

namespace GraphicsTools.Alundra
{
    public class DatasBin
    {
        public DBHeader header;
        public GameMap[] gamemaps;
        public string binfile;
        public DatasBin(string binfile)
        {
            this.binfile = binfile;
            using (var br = new BinaryReader(File.OpenRead(binfile)))
            {
                header = new DBHeader(br);
                

                
#if DEBUG       //verify maps
                for (int dex = 0; dex < header.gamemaps.Length; dex++)
                {
                    if (header.gamemaps[dex] > 0)
                    {
                        br.BaseStream.Position = header.gamemaps[dex];
                        if (br.BaseStream.Position != br.BaseStream.Length)
                        {
                            int check = br.ReadInt32();
                            Debug.Assert(check == 28);
                        }
                    }
                }
#endif

                gamemaps = new GameMap[header.gamemaps.Length];
                for (int dex = 0; dex < header.gamemaps.Length; dex++)
                {
                    if (header.gamemaps[dex] > 0 && header.gamemaps[dex] < br.BaseStream.Length)
                    {
                        gamemaps[dex] = new GameMap(br, header.gamemaps[dex]);
                    }
                }


            }
        }

        public BinaryReader OpenBin()
        {
            return new BinaryReader(File.OpenRead(binfile));
        }

    }

    public class GameMap
    {
        public GameMap(BinaryReader br, long offset)
        {
            //read header
            br.BaseStream.Position = binoffset = offset;
            header = new GameMapHeader(br);
            
            //just read mapid
            br.BaseStream.Position = binoffset + header.infoblock;
            info = new GameMapInfo(br.ReadInt32());

        }
        public long binoffset;
        public GameMapHeader header;
        public GameMapInfo info;
        public SpriteInfo spriteinfo;
        public ScrollScreen scrollscreen;
        public Map map;
        public string[] strings;
        public bool loaded = false;
        byte[] tilesheetimagedata;
        public Bitmap tilesheetbmp;
        byte[] spritesheetimagedata;
        public Bitmap spritesheetbmp;
        int numspritesheets = 6;
        public void Load(BinaryReader br)
        {
            //read info
            br.BaseStream.Position = binoffset + header.infoblock;
            info = new GameMapInfo(br);

            //map
            br.BaseStream.Position = binoffset + header.mapblock;
            map = new Map(br);
            header.walltilessize = header.tilesheets - (map.walltilesoffset + header.mapblock);
            header.mapsize -= header.walltilessize;

            //tilesheet
            br.BaseStream.Position = binoffset + header.tilesheets + 6;
            byte[] buff = new byte[header.spriteinfo - header.tilesheets];
            br.Read(buff, 0, buff.Length);
            tilesheetimagedata = new byte[256 * 256 * 6 / 2];//6 256x256 4bpp bitmaps
            Utils.Deflate(buff, tilesheetimagedata);

            //spriteinfo
            br.BaseStream.Position = binoffset + header.spriteinfo;
            spriteinfo = new SpriteInfo(br);

            //spritesheet
            br.BaseStream.Position = binoffset + header.spritesheets + 6;
            buff = new byte[header.scrollscreen - header.spritesheets - 6];
            br.Read(buff, 0, buff.Length);
            spritesheetimagedata = new byte[256 * 256 * numspritesheets / 2];//numspritesheets 256x256 4bpp bitmaps
            Utils.Deflate(buff, spritesheetimagedata);

            //scrollscreen
            scrollscreen = new ScrollScreen(br);

            //read string table
            br.BaseStream.Position = binoffset + header.stringtable;
            strings = new string[info.numstrings];
            short[] stringoffsets = new short[info.numstrings];
            for (int dex = 0; dex < info.numstrings; dex++)
            {
                stringoffsets[dex] = br.ReadInt16();
            }
            for (int dex = 0; dex < info.numstrings; dex++)
            {
                if (stringoffsets[dex] != -1)
                {
                    strings[dex] = "";
                    br.BaseStream.Position = binoffset + header.stringtable + stringoffsets[dex];
                    char c = br.ReadChar();
                    while (c != '\0')
                    {
                        strings[dex] += c;
                        c = br.ReadChar();
                    }
                }
            }
            header.stringsize = (int)(br.BaseStream.Position - binoffset) - header.stringtable;

            //loaded = true;
        }

        public Bitmap GenerateSpriteBitmap(SIImage img, Color[] pal)
        {
            byte[] buff = new byte[img.swidth * img.sheight * 4 / 8];

            for (int y = 0; y < img.sheight; y++)
                Buffer.BlockCopy(spritesheetimagedata, (img.sy + y) * 256 / 2 + img.sx / 2, buff, y * img.swidth / 2, img.swidth / 2);

            return Utils.BitmapFromPsxBuff(buff, img.swidth, img.sheight, 4, pal);
        }

        public Bitmap GenerateTileBitmap(int tile,Color[]pal)
        {
            Debug.Assert(tile < 10 * 16 * 6, "Bad tile index!", "unexpectedly large tile index of {0}", tile);
            byte[] tilebuff = new byte[24 * 16 * 4 / 8];
            int tilex = tile%10 * 24;
            int tiley = tile/10 * 16;
            if (tile < 10 * 16 * 6)
            {
                for (int y = 0; y < 16; y++)
                    Buffer.BlockCopy(tilesheetimagedata, (tiley + y) * 256 / 2 + tilex / 2, tilebuff, y * 24 / 2, 24 / 2);
            }
            return Utils.BitmapFromPsxBuff(tilebuff, 24, 16, 4, pal);
        }
        public Bitmap GenerateTileSheetBmp(Color[] pal)
        {
            tilesheetbmp = Utils.BitmapFromPsxBuff(tilesheetimagedata, 256, 256 * 6, 4, pal);
            return tilesheetbmp;
        }

        public Bitmap GenerateSpriteSheetBmp(Color[] pal)
        {
            spritesheetbmp = Utils.BitmapFromPsxBuff(spritesheetimagedata, 256, 256 * numspritesheets, 4, pal);
            return spritesheetbmp;
        }
    }

    public class Map
    {
        public Map(BinaryReader br)
        {
            long binoffset = br.BaseStream.Position;

            width = br.ReadByte();
            height = br.ReadByte();
            width2 = br.ReadByte();
            height2 = br.ReadByte();

            br.BaseStream.Position = binoffset + 1540;//why this number?

            maptiles = new MapTile[width * height];
            for (int dex = 0;dex<maptiles.Length;dex++)
            {
                maptiles[dex] = new MapTile(br);
            }

            walltilesoffset = (int)(br.BaseStream.Position - binoffset);

            //load wall tiles
            for (int dex = 0; dex < maptiles.Length; dex++)
            {
                maptiles[dex].LoadWallTiles(br, binoffset + walltilesoffset);
            }
        }

        public int width;
        public int height;
        public int width2;
        public int height2;

        public int walltilesoffset;

        public MapTile[] maptiles;
        
    }
    public class MapTile
    {
        public MapTile(BinaryReader br)
        {
            Int64 i = br.ReadUInt32();
            walkability = (byte)(i & 0xff);
            i >>= 8;
            groundproperty = (byte)(i & 0xff);
            i >>= 8;
            slope = (byte)(i & 0xff);
            i >>= 8;
            height = (byte)(i & 0xff);

            i = br.ReadUInt16();
            tileid = (short)i;
            if (i == 0xffff)
            {
                palette = -1;
                tile = -1;
            }
            else
            {
                palette = (short)((i & 0xf000) >> 12);
                tile = (short)(i & 0x3ff);
            }
            tilesoffset = br.ReadInt16();
            if (tilesoffset != -1)
                tilesoffset *= 2;

        }
        public byte walkability;
        public byte groundproperty;
        public byte slope;
        public byte height;
        public short tileid;
        public short palette;
        public short tile;
        public short tilesoffset;
        public WallTiles walltiles;
        public void LoadWallTiles(BinaryReader br, long offset)
        {
            if (tilesoffset != -1)
            {
                br.BaseStream.Position = offset + tilesoffset;
                walltiles = new WallTiles(br);
            }
        }
    }

    public class WallTiles
    {
        public WallTiles(BinaryReader br)
        {
            offset = br.ReadSByte();
            count = br.ReadByte();
            tiles = new short[count];
            //if ((flag != 0 && flag != 255) || count==0 || count == 255)
            //{
            //    flag = flag;
            //}
            
            for (int dex =0;dex<count;dex++)
            {
                tiles[dex] = br.ReadInt16();
            }
        }
        public sbyte offset;
        public byte count;
        public short[] tiles;
    }

    public class ScrollScreen
    {
        public ScrollScreen(BinaryReader br)
        {
            unknown1 = br.ReadInt32();
            unknown2 = br.ReadInt32();
            unknown3 = br.ReadInt32();
            unknown4 = br.ReadInt32();
            unknown5 = br.ReadInt32();
            unknown6 = br.ReadInt32();
            unknown7 = br.ReadInt32();
            unknown8 = br.ReadInt32();
        }
        public int unknown1;
        public int unknown2;
        public int unknown3;
        public int unknown4;
        public int unknown5;
        public int unknown6;
        public int unknown7;
        public int unknown8;
    }

    public class SpriteInfo
    {
        public SpriteInfo(BinaryReader br)
        {
            binoffset = br.BaseStream.Position;
            
            header = new SpriteInfoHeader(br);
            
            //read sector5 table
            br.BaseStream.Position = binoffset + header.sector5tablepointer;
            sector5table = new int[0xff];
            for (int dex = 0; dex < sector5table.Length; dex++)
            {
                sector5table[dex] = br.ReadInt32();
            }

            //read palettes
            br.BaseStream.Position = binoffset + header.spritepalettespointer;
            int maxpalettes = 32;
            palettes = new System.Drawing.Color[maxpalettes][];
            byte[] buff = new byte[maxpalettes * 16 * 2];
            br.Read(buff, 0, buff.Length);
            int buffdex = 0;
            for (int dex = 0; dex < maxpalettes; dex++)
            {
                palettes[dex] = new System.Drawing.Color[16];
                for (int cdex = 0; cdex < 16; cdex++)
                {
                    byte b2 = buff[buffdex++];
                    byte b1 = buff[buffdex++];
                    palettes[dex][cdex] = Utils.FromPsxColor((b1 << 8) | b2);
                }
            }
            palettesbitmap = Utils.BitmapFromPsxBuff(buff, 16, maxpalettes, 16, null);

            //read sector1
            sector1 = new SpriteInfoSector1(br, binoffset, header);

            //read sector2
            br.BaseStream.Position = binoffset + header.sector2pointer;
            sector2 = new SpriteInfoSector2(br);

            //read sector 4
            br.BaseStream.Position = binoffset + header.sector4pointer;
            sector4 = new SpriteInfoSector4(br);

            //read sector5 records;
            sector5records = new Sector5Record[sector5table.Length];
            for (int dex = 0; dex < sector5records.Length; dex++)
            {
                if (sector5table[dex] != -1)
                {
                    br.BaseStream.Position = binoffset + sector5table[dex];
                    sector5records[dex] = new Sector5Record(br, binoffset);
                }
            }
        }

        public SpriteInfoHeader header;
        public SpriteInfoSector1 sector1;
        public SpriteInfoSector2 sector2;
        public SpriteInfoSector4 sector4;

        public int[] sector5table;
        public Sector5Record[] sector5records;

        long binoffset;

        public System.Drawing.Color[][] palettes;
        public Bitmap palettesbitmap;
    }

    public class Sector5Record
    {
        public Sector5Record(BinaryReader br, long binoffset)
        {
            
            header = new Sector5Header(br, binoffset);
            animoffsets = new int[(header.unknownpointer - header.animationoffsetspointer) / 2];
            for (int dex = 0; dex < animoffsets.Length; dex++)
            {
                animoffsets[dex] = br.ReadInt16();
            }
        }

        public SIAnimation GetAnimation(BinaryReader br, int animationoffset)
        {
            br.BaseStream.Position = header.binoffset + header.animationspointer + animationoffset;

            var anim = new SIAnimation(br, header);

            return anim;
        }

        
        public Sector5Header header;
        public int[] animoffsets;

    }

    public class Sector5Header
    {
        public Sector5Header(BinaryReader br, long binoffset)
        {
            this.binoffset = binoffset;
            animationoffsetspointer = br.ReadInt32();
            animationspointer = br.ReadInt32();
            unknownpointer = br.ReadInt32();
            framespointer = br.ReadInt32();
            u1 = br.ReadByte();
            u2 = br.ReadByte();
            u3 = br.ReadByte();
            u4 = br.ReadByte();
            u5 = br.ReadByte();
            u6 = br.ReadByte();
            u7 = br.ReadByte();
            u8 = br.ReadByte();
            u9 = br.ReadByte();
            u10 = br.ReadByte();
            u11 = br.ReadByte();
            u12 = br.ReadByte();
            u13 = br.ReadByte();
            u14 = br.ReadByte();
            u15 = br.ReadByte();
            u16 = br.ReadByte();
        }
        public long binoffset;

        public int animationoffsetspointer;
        public int animationspointer;
        public int unknownpointer;
        public int framespointer;
        public byte u1;
        public byte u2;
        public byte u3;
        public byte u4;
        public byte u5;
        public byte u6;
        public byte u7;
        public byte u8;
        public byte u9;
        public byte u10;
        public byte u11;
        public byte u12;
        public byte u13;
        public byte u14;
        public byte u15;
        public byte u16;
    }


    public class SIAnimation
    {
        public SIAnimation(BinaryReader br, Sector5Header header)
        {
            frames = new SIFrame[32];//32 max frames?
            for (int dex = 0; dex < frames.Length; dex++)
            {
                //read two test bytes to check for the end of the list
                short test = br.ReadInt16();
                if (test == 0)
                    break;
                numframes++;
                br.BaseStream.Position -= 2;

                frames[dex] = new SIFrame(br, header);
            }
        }
        public int numframes;
        public SIFrame[] frames;
    }

    public class SIFrame
    {
        public SIFrame(BinaryReader br, Sector5Header header)
        {
            delay = br.ReadByte();
            unknown = br.ReadInt16();
            imagesetpointer = br.ReadInt16() * 2;
            
            
            //load images
            long savepos = br.BaseStream.Position;

            br.BaseStream.Position = header.binoffset + header.framespointer + imagesetpointer;
            images = new SIImageSet(br);

            br.BaseStream.Position = savepos;
        }



        public byte delay;//top bit masked
        public short unknown;//-1
        public int imagesetpointer;
        public SIImageSet images;
    }

    public class SIImageSet
    {
        public SIImageSet(BinaryReader br)
        {
            palette = br.ReadByte();//palette?
            numimages = br.ReadByte();
            images = new SIImage[numimages];
            for (int dex = 0; dex < numimages; dex++)
            {
                images[dex] = new SIImage(br);
            }
        }

        public byte palette;
        public byte numimages;
        public SIImage[] images;
    }

    public class SIImage
    {
        public SIImage(BinaryReader br)
        {
            u1 = br.ReadByte();
            u2 = br.ReadByte();
            sx = br.ReadByte();
            sy = br.ReadByte();
            swidth = br.ReadByte();
            sheight = br.ReadByte();
            x1 = br.ReadSByte();
            y1 = br.ReadSByte();
            x2 = br.ReadSByte();
            y2 = br.ReadSByte();
            x3 = br.ReadSByte();
            y3 = br.ReadSByte();
            x4 = br.ReadSByte();
            y4 = br.ReadSByte();
        }

        public byte u1;
        public byte u2;
        public byte sx;
        public byte sy;
        public byte swidth;
        public byte sheight;
        public sbyte x1;
        public sbyte y1;
        public sbyte x2;
        public sbyte y2;
        public sbyte x3;
        public sbyte y3;
        public sbyte x4;
        public sbyte y4;
    }

    public class SpriteInfoHeader
    {
        public SpriteInfoHeader(BinaryReader br)
        {
            sector2pointer = br.ReadInt32();
            sector3pointer = br.ReadInt32();
            sector4pointer = br.ReadInt32();
            sector5tablepointer = br.ReadInt32();
            unknown1pointer = br.ReadInt32();
            spritepalettespointer = br.ReadInt32();
            sector1apointer = br.ReadInt32();
            sector1bpointer = br.ReadInt32();
            sector1cpointer = br.ReadInt32();
            sector1dpointer = br.ReadInt32();
            sector1epointer = br.ReadInt32();
            sector1fpointer = br.ReadInt32();

            sector2size = sector3pointer - sector2pointer;
            sector3size = sector4pointer - sector3pointer;
            sector4size = -1;// unknown4 - unknown3;
            sector5tablesize = unknown1pointer - sector5tablepointer;
            unknown1size = spritepalettespointer - unknown1pointer;
            spritepalettessize = sector1apointer - spritepalettespointer;
            sector1asize = sector1bpointer - sector1apointer;
            sector1bsize = sector1cpointer - sector1bpointer;
            sector1csize = sector1dpointer - sector1cpointer;
            sector1dsize = sector1epointer - sector1dpointer;
            sector1esize = sector1fpointer - sector1epointer;
            sector1fandremainingsize = sector2pointer - sector1fpointer;
        }

        public int sector2pointer;
        public int sector2size;
        public int sector3pointer;
        public int sector3size;
        public int sector4pointer;
        public int sector4size;
        public int sector5tablepointer;
        public int sector5tablesize;
        public int unknown1pointer;
        public int unknown1size;
        public int spritepalettespointer;
        public int spritepalettessize;
        public int sector1apointer;
        public int sector1asize;
        public int sector1bpointer;
        public int sector1bsize;
        public int sector1cpointer;
        public int sector1csize;
        public int sector1dpointer;
        public int sector1dsize;
        public int sector1epointer;
        public int sector1esize;
        public int sector1fpointer;
        public int sector1fsize;//calced when reading sector1
        public int sector1fandremainingsize;
    }

    public class SpriteInfoSector1
    {
        public SpriteInfoSector1(BinaryReader br, long binoffset, SpriteInfoHeader header)
        {
            
            int table_size = 0;
            short firstoffset = 0;

            //read sector1a
            br.BaseStream.Position = binoffset + header.sector1apointer;
            table_size = header.sector1asize / 2;
            sector1atable = new short[table_size];
            for (int dex = 0; dex < table_size; dex++)
            {
                sector1atable[dex] = br.ReadInt16();
                if (firstoffset == 0 && sector1atable[dex] != 0)
                    firstoffset = sector1atable[dex];
            }

            //read sector1b
            br.BaseStream.Position = binoffset + header.sector1bpointer;
            table_size = header.sector1bsize / 2;
            sector1btable = new short[table_size];
            for (int dex = 0; dex < table_size; dex++)
            {
                sector1btable[dex] = br.ReadInt16();
                if (firstoffset == 0 && sector1btable[dex] != 0)
                    firstoffset = sector1btable[dex];
            }

            //read sector1c
            br.BaseStream.Position = binoffset + header.sector1cpointer;
            table_size = header.sector1csize / 2;
            sector1ctable = new short[table_size];
            for (int dex = 0; dex < table_size; dex++)
            {
                sector1ctable[dex] = br.ReadInt16();
                if (firstoffset == 0 && sector1ctable[dex] != 0)
                    firstoffset = sector1ctable[dex];
            }

            //read sector1d
            br.BaseStream.Position = binoffset + header.sector1dpointer;
            table_size = header.sector1dsize / 2;
            sector1dtable = new short[table_size];
            for (int dex = 0; dex < table_size; dex++)
            {
                sector1dtable[dex] = br.ReadInt16();
                if (firstoffset == 0 && sector1dtable[dex] != 0)
                    firstoffset = sector1dtable[dex];
            }

            //read sector1e
            br.BaseStream.Position = binoffset + header.sector1epointer;
            table_size = header.sector1esize / 2;
            sector1etable = new short[table_size];
            for (int dex = 0; dex < table_size; dex++)
            {
                sector1etable[dex] = br.ReadInt16();
                if (firstoffset == 0 && sector1etable[dex] != 0)
                    firstoffset = sector1etable[dex];
            }

            //read sector1f
            header.sector1fsize = (header.sector1apointer + firstoffset) - header.sector1fpointer;
            br.BaseStream.Position = binoffset + header.sector1fpointer;
            table_size = header.sector1fsize / 2;
            if (table_size < 0)
                table_size = 16;
            sector1ftable = new short[table_size];
            for (int dex = 0; dex < table_size; dex++)
            {
                sector1ftable[dex] = br.ReadInt16();
            }

            //set binoffset for sector1
            this.binoffset = binoffset + header.sector1apointer; ;
        }

        public byte[] GetByteCode(BinaryReader br, int sector1offset)
        {

            byte[] bytes = new byte[255];
            int dex = 0;
            br.BaseStream.Position = binoffset + sector1offset;
            
            while(true)
            {
                Debug.Assert(dex < bytes.Length, "ByteCodes larger than 255");

                byte b = br.ReadByte();
                if (b == 0)//what does 0 mean?
                {
                    bytes[dex++] = b;
                }
                else if (b == 0xff)//end
                {
                    bytes[dex++] = b;
                    return bytes;
                }
                else
                {
                    bytes[dex++] = b;
                    //skip ahead by parameter length
                }
            }
        }

        long binoffset;
        public short[] sector1atable;
        public short[] sector1btable;
        public short[] sector1ctable;
        public short[] sector1dtable;
        public short[] sector1etable;
        public short[] sector1ftable;
    }


    public class SpriteInfoSector2
    {
        public SpriteInfoSector2(BinaryReader br)
        {
            br.BaseStream.Position += 2;

            entities = new SISector2EntityRecord[128];
            for (int dex = 0; dex < entities.Length; dex++)
            {
                //read two test bytes to check for the end of the list
                short test = br.ReadInt16();
                if (test == 0)
                    break;
                br.BaseStream.Position -= 2;

                //read the record
                entities[dex] = new SISector2EntityRecord(br);
            }
        }
        public SISector2EntityRecord[] entities;
    }

    public class SISector2EntityRecord
    {
        public SISector2EntityRecord(BinaryReader br)
        {
            u1 = br.ReadByte();
            u2 = br.ReadByte();
            u3 = br.ReadByte();
            spritecode = br.ReadByte();
            sector5tableindex = br.ReadByte();
            xpos = br.ReadByte();
            ypos = br.ReadByte();
            height = br.ReadByte();
            sector1a_bahavior_index = br.ReadByte();
            sector1b_unknown_index = br.ReadByte();
            sector1c_unknown_index = br.ReadByte();
            sector1d_unknown_index = br.ReadByte();
            sector1e_unknown_index = br.ReadByte();
            sector1f_dialog_index = br.ReadByte();
            u7 = br.ReadByte();
            u8 = br.ReadByte();
            u9 = br.ReadByte();
            u10 = br.ReadByte();
            u11 = br.ReadByte();
            u12 = br.ReadByte();
        }

        public byte u1;//33
        public byte u2;//3b
        public byte u3;//1
        public byte spritecode;//0,c0,c1,c2,c3,80
        public byte sector5tableindex;
        public byte xpos;//divide by 2
        public byte ypos;//divide by 2
        public byte height;//divide by 2
        public byte sector1a_bahavior_index;
        public byte sector1b_unknown_index;
        public byte sector1c_unknown_index;
        public byte sector1d_unknown_index;
        public byte sector1e_unknown_index;
        public byte sector1f_dialog_index;
        public byte u7;
        public byte u8;
        public byte u9;
        public byte u10;
        public byte u11;
        public byte u12;
    }

    public class SpriteInfoSector3
    {

    }

    public class SpriteInfoSector4
    {
        public SpriteInfoSector4(BinaryReader br)
        {
            br.BaseStream.Position += 2;

            records = new SISector4Record[64];
            for (int dex = 0; dex < records.Length; dex++)
            {
                //read two test bytes to check for the end of the list
                short test = br.ReadInt16();
                if (test == 0)
                    break;
                br.BaseStream.Position -= 2;

                //read the record
                records[dex] = new SISector4Record(br);
            }
        }

        public SISector4Record[] records;
    }

    public class SISector4Record
    {
        public SISector4Record(BinaryReader br)
        {
            u1 = br.ReadByte();
            u2 = br.ReadByte();
            u3 = br.ReadByte();
            u4 = br.ReadByte();
            u5 = br.ReadByte();
            u6 = br.ReadByte();
            u7 = br.ReadByte();
            u8 = br.ReadByte();
        }

        public byte u1;
        public byte u2;
        public byte u3;
        public byte u4;
        public byte u5;
        public byte u6;
        public byte u7;
        public byte u8;
    }

    public class GameMapInfo
    {
        public GameMapInfo(int mapid)
        {
            this.mapid = mapid;
        }

        public GameMapInfo(BinaryReader br)
        {
            long binoffset = br.BaseStream.Position;
            mapid = br.ReadInt32();
            numstrings = br.ReadInt16();
            unknown2048 = br.ReadInt16();
            unknown512 = br.ReadInt16();
            unknown7 = br.ReadInt16();
            unknown3882a = br.ReadByte();
            unknown3882b = br.ReadByte();
            uknown17 = br.ReadInt16();
            //read palettes
            int maxpalettes = 32;
            palettes = new System.Drawing.Color[maxpalettes][];
            byte[] buff = new byte[maxpalettes * 16 * 2];
            br.Read(buff, 0, buff.Length);
            int buffdex = 0;
            for (int dex = 0; dex < maxpalettes; dex++)
            {
                palettes[dex] = new System.Drawing.Color[16];
                for (int cdex = 0; cdex < 16; cdex++)
                {
                    byte b2 = buff[buffdex++];
                    byte b1 = buff[buffdex++];
                    palettes[dex][cdex] = Utils.FromPsxColor((b1 << 8) | b2);
                }
            }
            palettesbitmap = Utils.BitmapFromPsxBuff(buff, 16, maxpalettes, 16, null);

            //read portals
            br.BaseStream.Position = binoffset + 1066;
            portalflag1 = br.ReadByte();
            portalflag2 = br.ReadByte();
            int maxportals = 64;
            portals = new Portal[maxportals];
            for (int dex = 0; dex < portals.Length; dex++)
            {
                portals[dex] = new Portal(br);
            }
        }

        public int mapid;
        public short numstrings;
        public short unknown2048;
        public short unknown512;
        public short unknown7;
        public byte unknown3882a;
        public byte unknown3882b;
        public short uknown17;
        public System.Drawing.Color[][] palettes;
        public Bitmap palettesbitmap;
        public byte portalflag1;
        public byte portalflag2;
        public Portal[] portals;

    }
    public class Portal
    {
        public Portal(BinaryReader br)
        {
            x1 = br.ReadByte();
            y1 = br.ReadByte();
            x2 = br.ReadByte();
            y2 = br.ReadByte();
            destmapid = br.ReadInt16();
            destx = br.ReadByte();
            desty = br.ReadByte();
            unknown1 = br.ReadByte();
            unknown2 = br.ReadByte();
            unknown3 = br.ReadByte();
            unknown4 = br.ReadByte();
        }
        public byte x1, y1;
        public byte x2, y2;
        public short destmapid;
        public byte destx, desty;
        public byte unknown1, unknown2;
        public byte unknown3, unknown4;
    }
    public class GameMapHeader
    {
        public GameMapHeader(BinaryReader br)
        {
            infoblock = br.ReadInt32();
            mapblock = br.ReadInt32();
            tilesheets = br.ReadInt32();
            spriteinfo = br.ReadInt32();
            spritesheets = br.ReadInt32();
            scrollscreen = br.ReadInt32();
            stringtable = br.ReadInt32();

            infosize = mapblock - infoblock;
            mapsize = tilesheets - mapblock;
            tilessize = spriteinfo - tilesheets;
            sinfosize = spritesheets - spriteinfo;
            spritessize = scrollscreen - spritesheets;
            scrollsize = stringtable - scrollscreen;
            //string table is called later
        }

        public int infosize;
        public int mapsize;
        public int walltilessize;
        public int tilessize;
        public int sinfosize;
        public int spritessize;
        public int scrollsize;
        public int stringsize;

        public int infoblock;
        public int mapblock;
        public int tilesheets;
        public int spriteinfo;
        public int spritesheets;
        public int scrollscreen;//shadow, sky or distant background
        public int stringtable;
    }

    public class DBHeader
    {
        public DBHeader(BinaryReader br)
        {
            unknownblock = br.ReadUInt32();
            alundrasprites = br.ReadUInt32();
            alundraspritesrepeat = br.ReadUInt32();
            stringtabledebug = br.ReadUInt32();
            stringtabledebugrepeat = br.ReadUInt32();
            unknownmapa = br.ReadUInt32();
            unknownmapb = br.ReadUInt32();
            unknownmapb2 = br.ReadUInt32();
            unknownmapb3 = br.ReadUInt32();
            unknownmapb4 = br.ReadUInt32();
            int maxmaps = 502;
            gamemaps = new UInt32[maxmaps];
            for (int dex = 0; dex < maxmaps; dex++)
            {
                gamemaps[dex] = br.ReadUInt32();
            }
        }

        public UInt32 unknownblock;
        public UInt32 alundrasprites;
        public UInt32 alundraspritesrepeat;
        public UInt32 stringtabledebug;
        public UInt32 stringtabledebugrepeat;
        public UInt32 unknownmapa;
        public UInt32 unknownmapb;
        public UInt32 unknownmapb2;
        public UInt32 unknownmapb3;
        public UInt32 unknownmapb4;
        public UInt32[] gamemaps;
    }
}
