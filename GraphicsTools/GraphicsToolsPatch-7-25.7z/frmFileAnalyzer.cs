﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using alundramultitool;

namespace GraphicsTools
{
    public partial class frmFileAnalyzer : Form
    {
        public frmFileAnalyzer()
        {
            InitializeComponent();
        }

        public string datafile;

        public int offset;
        int chunklength = 1024*1024;
        byte[] data;

        int ParseNum(string num)
        {
            int i = 0;
            if (num.StartsWith("0x"))
            {
                int.TryParse(num.Replace("0x", ""), System.Globalization.NumberStyles.AllowHexSpecifier, null, out i);
            }
            else
            {
                int.TryParse(num, out i);
            }
            return i;
        }

        private void frmFileAnalyzer_Load(object sender, EventArgs e)
        {
            loadchunk(offset);
        }

        int instOffset = 0;
        void loadchunk(int offset)
        {
            this.offset = offset;
            data = new byte[chunklength];
            var stream = File.OpenRead(datafile);
            stream.Position = offset;
            int numread = stream.Read(data, 0, chunklength);
            stream.Close();
            rtfText.LoadFile(new MemoryStream(data), RichTextBoxStreamType.PlainText);
            rtfText.Select(0, 0);

            instOffset = ParseNum(txtInstructionsOffset.Text);

            lstInstructions.Items.Clear();
            var mips = new MIPS();
            for (int dex = 0; dex < 10000; dex+=4)
            {
                lstInstructions.Items.Add(string.Format("{0}:    {1}", (instOffset + offset + dex).ToString("x8"), mips.DisplayMIPSInstruction((uint)(data[dex] | data[dex + 1] << 8 | data[dex + 2] << 16 | (uint)data[dex + 3] << 24))));
            }
        }

        void DisplayData(int pos)
        {
            txtOffset.Text = offset.ToString();
            lblCursorOffset.Text = (pos + offset).ToString();
            lblRelOffset.Text = pos.ToString();
            lblSelLength.Text = rtfText.SelectionLength.ToString();

            lbl8bit.Text = data[pos].ToString();
            lbl16bit.Text = ((long)data[pos] | (long)data[pos + 1] << 8).ToString();
            lbl32bit.Text = ((long)data[pos] | (long)data[pos + 1] << 8 | (long)data[pos + 2] << 16 | (long)data[pos + 3] << 24).ToString();

            lbl4bita.Text = ((data[pos] & 0xf0) >> 4).ToString();
            lbl4bitb.Text = (data[pos] & 0xf).ToString();
        }

        private void rtfText_SelectionChanged(object sender, EventArgs e)
        {
            if (rtfText.SelectionStart >= 0)
                DisplayData(rtfText.SelectionStart);
        }

        frmViewer viewer;
        frmViewer pal;

        private void btnViewImage_Click(object sender, EventArgs e)
        {
            int stride, width, height,startx,starty;
            int.TryParse(txtStride.Text, out stride);
            int.TryParse(txtWidth.Text, out width);
            int.TryParse(txtHeight.Text, out height);
            int.TryParse(txtStartx.Text, out startx);
            int.TryParse(txtStarty.Text, out starty);

            int imagestart = rtfText.SelectionStart;

            int bpp = 4;
            byte[]imagedata = new byte[width*height*bpp/8];

            if (stride == -1)
            {
                //compressed
                int imagedex = 0;
                int buffdex = imagestart;
                while(imagedex < imagedata.Length)
                {
                    byte b = data[buffdex++];
                    if (b == 0xad)
                    {
                        int seek = data[buffdex++];
                        if (seek == 0)
                        {
                            imagedata[imagedex++] = b;
                        }
                        else
                        {
                            int len = data[buffdex++];
                            int seekdex = imagedex - seek;
                            while (len-- > 0)
                                imagedata[imagedex++] = imagedata[seekdex++];
                        }
                    }
                    else
                        imagedata[imagedex++] = b;
                }
            }
            else
            {
                for (int y = 0; y < height; y++)
                {
                    Buffer.BlockCopy(data, imagestart + (y + starty) * stride + (startx / 2), imagedata, y * width * bpp / 8, width * bpp / 8);
                }
            }

            int paloffset = 0;
            Color[] palettes = new Color[(int)Math.Pow(2, bpp)];
            if (Program.palette != null)
                palettes = Program.palette;
            else
            {
                for (int dex = 0; dex < palettes.Length; dex++)
                {
                    int ddex = imagestart + paloffset + dex * 2;
                    palettes[dex] = Utils.FromPsxColor(data[ddex + 1], data[dex]);// Color.FromArgb(255, (data[ddex + 1] & 0x1f) << 3, ((data[ddex + 1] & 0xe0) >> 2) | ((data[ddex] & 0x3) << 6), data[ddex] & 0x7c);
                }
            }
            viewer = new frmViewer();
            viewer.Show();
            viewer.init(imagedata, width, height, palettes);
        }

        private void btnJump_Click(object sender, EventArgs e)
        {
            offset = ParseNum(txtOffset.Text);
            loadchunk(offset);
        }

        private void btnViewPal_Click(object sender, EventArgs e)
        {
            int stride, width, height;
            int.TryParse(txtStride.Text, out stride);
            int.TryParse(txtWidth.Text, out width);
            int.TryParse(txtHeight.Text, out height);

            int palettestart = rtfText.SelectionStart;

            int bpp = 16;
            byte[] imagedata = new byte[width * height * bpp / 8];
            for (int y = 0; y < height; y++)
            {
                Buffer.BlockCopy(data, palettestart + y * stride, imagedata, y * width * bpp / 8, width * bpp / 8);

            }
            var frm = new frmViewer();
            frm.Show();
            frm.initpalette(viewer, imagedata, width, height);
        }

        private void rtfText_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (rtfText.SelectionStart >= 0)
            {
                lstInstructions.SelectedIndex = (rtfText.SelectionStart) / 4;
                
            }
        }

    }
}
