﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace alundramultitool
{
    public class MIPS
    {
        int ValAtOffset(uint instruction, int width, int bitoffset)
        {
            return (int)((instruction & (width << bitoffset)) >> bitoffset);
        }

        int SignedValAtOffset(uint instruction, int width, int bitoffset)
        {
            int signoffset = 0;
            while (width >> signoffset > 1)
                signoffset++;
            return (int)(ValAtOffset(instruction, width ^ (1 << signoffset), bitoffset) | (ValAtOffset(instruction, 1, signoffset) == 1 ? (0xffffffff >> signoffset) << signoffset : 0));
        }


        public string GetRegister(int num)
        {
            return "r" + num;
        }
        
        public string DisplayMIPSInstruction(uint instruction)
        {
            int opcode = ValAtOffset(instruction, 0x3f, 26);

            string onevalformat = "{0} {1}";
            string twovalformat = "{0} {1}, {2}";
            string threevalformat = "{0} {1}, {2}, {3}";
            string threevalmemoryformat = "{0} {1}, {3}({2})";

            if (instruction == 0)
                return "nop";

            if (opcode == 0x0)//R type instruction
            {
                
                int funct = (int)(instruction & 0x3f);
                string rs = GetRegister(ValAtOffset(instruction, 0x1f, 6 + 5 * 3));
                string rt = GetRegister(ValAtOffset(instruction, 0x1f, 6 + 5 * 2));
                string rd = GetRegister(ValAtOffset(instruction, 0x1f, 6 + 5 * 1));
                int shamt = ValAtOffset(instruction, 0x1f, 6 + 5 * 0);
                
                switch (funct)
                {
                    case 0x20://add
                        return string.Format(threevalformat, "add", rd, rs, rt);
                    case 0x21://add unsigned
                        return string.Format(threevalformat, "addu", rd, rs, rt);
                    case 0x22://subtract
                        return string.Format(threevalformat, "sub", rd, rs, rt);
                    case 0x23://subtract unsigned
                        return string.Format(threevalformat, "subu", rd, rs, rt);
                    case 0x18://multiply
                        return string.Format(twovalformat, "mult", rs, rt);
                    case 0x19://multiply unsigned
                        return string.Format(twovalformat, "multu", rs, rt);
                    case 0x1a://divide
                        return string.Format(twovalformat, "div", rs, rt);
                    case 0x1b://divide unsigned
                        return string.Format(twovalformat, "divu", rs, rt);
                    case 0x10://move from hi
                        return string.Format(onevalformat, "mfhi", rd);
                    case 0x12://move from low
                        return string.Format(onevalformat, "mflo", rd);
                    case 0x24://and
                        return string.Format(threevalformat, "and", rd, rs, rt);
                    case 0x25://or
                        return string.Format(threevalformat, "or", rd, rs, rt);
                    case 0x26://xor
                        return string.Format(threevalformat, "xor", rd, rs, rt);
                    case 0x27://nor
                        return string.Format(threevalformat, "nor", rd, rs, rt);
                    case 0x2a://set on less than
                        return string.Format(threevalformat, "slt", rd, rs, rt);
                    case 0x0://shift left logical immediate
                        return string.Format(threevalformat, "sll", rd, rt, shamt);
                    case 0x2://shift right logical immediate
                        return string.Format(threevalformat, "srl", rd, rt, shamt);
                    case 0x3://shift right arithmetic immediate
                        return string.Format(threevalformat, "sra", rd, rt, shamt);
                    case 0x4://shift left logical
                        return string.Format(threevalformat, "sllv", rd, rt, rs);
                    case 0x6://shift right logical
                        return string.Format(threevalformat, "srlv", rd, rt, rs);
                    case 0x7://shift right arithmetic
                        return string.Format(threevalformat, "srav", rd, rt, rs);
                    case 0x8://jump register
                        return string.Format(onevalformat, "beq", rs);
                    default:
                        return "unknown R type funct: " + funct.ToString("x2");
                }
            }
            else if (opcode == 0x2 || opcode == 0x3)//J type instruction
            {
                int address = ValAtOffset(instruction, 0x3ffffff, 0);
                
                switch (opcode)
                {
                    case 0x2:
                        return string.Format(onevalformat, "j", address.ToString("x8"));
                    case 0x3:
                        return string.Format(onevalformat, "jal", address.ToString("x8"));
                }
            }
            else//I type instruction
            {
                string rs = GetRegister(ValAtOffset(instruction, 0x1f, 6 + 5 * 3));
                string rt = GetRegister(ValAtOffset(instruction, 0x1f, 6 + 5 * 2));
                string immediate = "0x" + ((short)SignedValAtOffset(instruction, 0xffff, 0)).ToString("x4");
                string immediateu = "0x" + ((short)ValAtOffset(instruction, 0xffff, 0)).ToString("x4");

                switch (opcode)
                {
                    case 0x8://add immediate
                        return string.Format(threevalformat, "addi", rt, rs, immediate);
                    case 0x9://add immediate unsigned
                        return string.Format(threevalformat, "addiu", rt, rs, immediateu);
                    case 0x23://load word
                        return string.Format(threevalmemoryformat, "lw", rt, rs, immediate);
                    case 0x21://load halfword
                        return string.Format(threevalmemoryformat, "lh", rt, rs, immediate);
                    case 0x25://load halfword unsigned
                        return string.Format(threevalmemoryformat, "lhu", rt, rs, immediate);
                    case 0x20://load byte
                        return string.Format(threevalmemoryformat, "lb", rt, rs, immediate);
                    case 0x24://load byte unsigned
                        return string.Format(threevalmemoryformat, "lbu", rt, rs, immediate);
                    case 0x2b://store word
                        return string.Format(threevalmemoryformat, "sw", rt, rs, immediate);
                    case 0x29://store halfword
                        return string.Format(threevalmemoryformat, "sh", rt, rs, immediate);
                    case 0x28://store byte
                        return string.Format(threevalmemoryformat, "sb", rt, rs, immediate);
                    case 0xf://load upper immediate
                        return string.Format(twovalformat, "lui", rt, immediate);
                    case 0xc://and immediate
                        return string.Format(threevalformat, "andi", rt, rs, immediate);
                    case 0xd://or immediate
                        return string.Format(threevalformat, "ori", rt, rs, immediate);
                    case 0xa://set on less than immediate
                        return string.Format(threevalformat, "andi", rt, rs, immediate);
                    case 0x4://branch on equal
                        return string.Format(threevalformat, "beq", rs, rt, immediate);
                    case 0x5://branch on not equal
                        return string.Format(threevalformat, "bne", rs, rt, immediate);
                    default:
                        return "unknown I type opcode: " + opcode.ToString("x2");

                }
            }
            

            return "";
        }
    }
}
